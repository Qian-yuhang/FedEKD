import argparse

def args_parser(args):
    parser = argparse.ArgumentParser()

    # differential privacy arguments
    # --epsilon：Specify privacy budget parameters, default is 100
    # --alpha：Specify Dirichlet Alpha parameter, default is 1
    parser.add_argument('--epsilon', type = float, default = 100, help = "privacy budget")
    parser.add_argument('--alpha', type = float, default = 1, help = "Dirichlet parameter")
    

    # konwdege distillation arguments
    # --m_num：Specify the number of KD data, default is 2
    # --cache_size：Specify the knowledge cache size, default is 160
    parser.add_argument('--m_num', type = int, default = 2, help = "KD data num")
    parser.add_argument('--cache_size', type = int, default = 160, help = "size of transfer konwledge cache")
    

    # federated arguments
    # --epochs：total training epochs，default is 50
    # --num_users：number of users，default is 10
    # --local_ep：local training epochs, default is 5
    # --combined_ep：combined distillation training epochs, default is 4
    # --train_bs：Specify the training batch size, default is 8
    # --bs：Specify the batch size for testing, default is 1024
    # --lr：Specify the learning rate, which defaults is 0.01
    # --momentum：SGD momentum, default is 0.9
    parser.add_argument('--epochs', type = int, default = 50, help = "total training epochs")
    parser.add_argument('--num_users', type = int, default = 10, help = "number of users: K")
    parser.add_argument('--local_ep', type = int, default = 5, help = "local training epochs: 5")
    parser.add_argument('--combined_ep', type = int, default = 4, help = "combined distillation training epochs: 4")
    parser.add_argument('--train_bs', type = int, default = 8, help = "local batch size: 8")
    parser.add_argument('--bs', type = int, default = 1024, help = "test batch size")
    parser.add_argument('--lr', type = float, default = 0.01, help = "learning rate")
    parser.add_argument('--momentum', type = float, default = 0.9, help = "SGD momentum (default: 0.9)")


    # other arguments
    # --dataset：name of dataset, default is mnist
    # --num_classes：Number of specified categories, default is 10
    # --gpu：Specify the GPU number to be used, default is 0, and -1 for CPU usage
    # --seed：Specify a random seed, default is 1, for repeatability of results
    # --public_data_ratio：Public dataset setting rate (divided by training set size), default is 10%

    parser.add_argument('--dataset', type = str, default = 'mnist', help = "name of dataset")
    parser.add_argument('--num_classes', type = int, default = 10, help = "number of classes")
    parser.add_argument('--gpu', type = int, default = 0, help = "GPU ID, -1 for CPU")
    parser.add_argument('--seed', type = int, default = 1, help = 'random seed (default: 1)')
    parser.add_argument('--public_data_ratio', type = float, default = 0.1, help = "public_data_ratio")

    args = parser.parse_args(args)
    return args
