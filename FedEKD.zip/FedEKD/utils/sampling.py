import numpy as np
from torch.utils.data import random_split

def partition_public(dataset_train, public_data_ratio):
    # Calculate the size of the dataset
    total_size = len(dataset_train)
    public_size = int(total_size * public_data_ratio)  # 10% for public dataset
    train_size = total_size - public_size  # 90% for training dataset

    # Randomly split dataset
    dataset_train, dataset_public = random_split(dataset_train, [train_size, public_size])
    
    return dataset_train, dataset_public


def local_data_partition(train_labels, alpha, local_size = 4800):
    range_length = local_size               # 4800
    CLASS_NUM = 10                          # 10

    category_dict = {}              # Sample index for each category
    category_used_data = {}         # The number of samples allocated for each category
    train_users_dict = {}           # Store allocation data for each user

    for cid in range(CLASS_NUM):
        category_used_data[cid] = 0
        flag = np.where(train_labels == cid)[0]                         # Use np.where to find all sample indexes with tags equal to the current category, and store them in the flag
        perb = np.random.permutation(len(flag))                         # Randomly shuffle the order of flags to ensure that each partitioned data is random
        flag = flag[perb]
        category_dict[cid] = flag                                       # Store the scrambled index in category_dict
        # print("category_dict:", len(category_dict[cid]))

    user_num = 10
    # user_num = int(np.ceil(len(train_labels)//range_length))            # user_num  10
    # Allocate data to each user (except for the last one)
    for uid in range(user_num - 1):
        p = np.random.dirichlet([alpha] * CLASS_NUM, size=1) * range_length     # The number of samples that should be allocated for each category
        p = np.array(np.round(p),dtype='int32')[0]                              # Round and convert to integer
        ix = p.argmax()
        p[ix] = p[ix] - (p.sum() - range_length)                                # Adjust the maximum value to meet the total sum
        assert p.sum() == range_length and (p>=0).mean() == 1.0                 # Assertion judgment

        data = []
        for cid in range(CLASS_NUM):
            s = category_used_data[cid]
            ed = s + p[cid]
            category_used_data[cid] += p[cid]
            data.append(category_dict[cid][s:ed])

        # After two rounds of alignment to fill in the data
        for i in range(2):
            if(len(np.concatenate(data)) < range_length):
                min_used = min(category_used_data, key=category_used_data.get)
                s = category_used_data[min_used]
                ed = s + range_length - len(np.concatenate(data))
                category_used_data[min_used] += (range_length - len(np.concatenate(data)))
                data.append(category_dict[min_used][s:ed])
        
        data = np.concatenate(data)
        data = set(data)
        train_users_dict[uid] = data

    data = []
    for cid in range(CLASS_NUM):
        s = category_used_data[cid]        
        data.append(category_dict[cid][s:])
    data = np.concatenate(data)
    data = set(data)
    train_users_dict[user_num-1] = data

    train_users = train_users_dict
    
    return train_users

def partition_data_dataset(y_train, n_nets, alpha):                         # n_nets = 10
    min_size = 0                # used to record the minimum amount of data in all subsets currently available
    K = 10
    N = y_train.shape[0]        # Obtain the sample size of the training dataset y_train
    print("N = " + str(N))      # Print sample quantity N
    net_dataidx_map = {}        # Initialize an empty dictionary net_dataidx_map to store the data index corresponding to each network (or client)

    while min_size < 10:
        idx_batch = [[] for _ in range(n_nets)]                                                                     # Initialize a list idx_batch containing n_nets empty lists, where each list stores a data index corresponding to the network
        for k in range(K):                                                                                          # K categories
            idx_k = np.where(y_train == k)[0]                                                                       # Obtain the index of all samples in category k
            np.random.seed(k)                                                                                       # Set the random seed to k to ensure that the random results of the same category are consistent every time the code is run
            proportions = np.random.dirichlet(np.repeat(alpha, n_nets))                                             # Generate a proportional vector of the Dirichlet distribution with a length of n_nets, where alpha is the parameter of the Dirichlet distribution
            np.random.shuffle(idx_k)                                                                                # Shuffle the index order of category k
            proportions = np.array([p * (len(idx_j) < N / n_nets) for p, idx_j in zip(proportions, idx_batch)])     # Adjust the proportions so that if the data volume of a subset exceeds N/n_nets, set its proportion to 0
            proportions = proportions / proportions.sum()                                                           # Normalize the ratio so that the sum of all ratios is 1
            proportions = (np.cumsum(proportions) * len(idx_k)).astype(int)[:-1]                                    # Calculate the cumulative ratio and multiply it by the number of samples in category k to obtain the partition points for each subset
            idx_batch = [idx_j + idx.tolist() for idx_j, idx in zip(idx_batch, np.split(idx_k, proportions))]       # Allocate the index of category k proportionally to each subset
            min_size = min([len(idx_j) for idx_j in idx_batch])


    # idx_batch = [[] for _ in range(n_nets)]
    # for k in range(K):
    #     idx_k = np.where(y_train == k)[0]
    #     np.random.seed(k)
    #     proportions = np.random.dirichlet(np.repeat(alpha, n_nets))
    #     np.random.shuffle(idx_k)
    #     proportions = np.array([p * (len(idx_j) < N / n_nets) for p, idx_j in zip(proportions, idx_batch)])
    #     proportions = proportions / proportions.sum()
    #     proportions = (np.cumsum(proportions) * len(idx_k)).astype(int)[:-1]
    #     idx_batch = [idx_j + idx.tolist() for idx_j, idx in zip(idx_batch, np.split(idx_k, proportions))]

    for j in range(n_nets):
        np.random.shuffle(idx_batch[j])
        net_dataidx_map[j] = idx_batch[j]
        
    return net_dataidx_map
