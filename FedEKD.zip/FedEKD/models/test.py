from torch.utils.data import DataLoader


def test_img(net_g, datatest, args):
    net_g.to(args.device)
    net_g.eval()
    # testing
    test_loss = 0
    correct = 0
    data_loader = DataLoader(datatest, batch_size = 512)  # args.bs
    for idx, (data, target) in enumerate(data_loader):
        data, target = data.to(args.device), target.to(args.device)
        log_probs = net_g(data)
        # get the index of the max log-probability
        y_pred = log_probs.data.max(1, keepdim=True)[1]
        correct += y_pred.eq(target.data.view_as(y_pred)).long().to(args.device).sum()

    accuracy = 100.00 * correct / len(data_loader.dataset)
    return accuracy