from torch.utils.data import Dataset


class CustomDatasetSplit(Dataset):
    def __init__(self, dataset, idxs, new_labels):
        self.dataset = dataset
        self.idxs = list(idxs)
        self.new_labels = new_labels  # 新的标签列表

    def __len__(self):
        return len(self.idxs)

    def __getitem__(self, item):
        # 从原始数据集中获取图像和标签
        image, _ = self.dataset[self.idxs[item]]
        # 返回图像和新的标签
        return image, self.new_labels[item]


class DatasetSplit(Dataset):
    def __init__(self, dataset, idxs):
        self.dataset = dataset
        self.idxs = list(idxs)

    def __len__(self):
        return len(self.idxs)

    def __getitem__(self, item):
        image, label = self.dataset[self.idxs[item]]
        return image, label

