from torch import nn
import torch.nn.functional as F

class MLP(nn.Module):
    def __init__(self, dim_in, dim_hidden, dim_out):
        super(MLP, self).__init__()
        self.layer_input = nn.Linear(dim_in, dim_hidden)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout()
        self.layer_hidden = nn.Linear(dim_hidden, dim_out)

    def forward(self, x):
        x = x.view(-1, x.shape[1]*x.shape[-2]*x.shape[-1])
        x = self.layer_input(x)
        x = self.dropout(x)
        x = self.relu(x)
        x = self.layer_hidden(x)
        return x


class CNNMnistKT(nn.Module):
    def __init__(self, args):
        super(CNNMnistKT, self).__init__()
        self.conv1 = nn.Conv2d(1, 32, kernel_size = 5)          # Conv2D: (1, 28, 28) -> (32, 24, 24)
        self.pool1 = nn.MaxPool2d(kernel_size = 2)              # MaxPooling2D: (32, 24, 24) -> (32, 12, 12)
        self.dropout1 = nn.Dropout(p = 0.2)                     # Assuming dropout rate is 20%

        self.conv2 = nn.Conv2d(32, 128, kernel_size = 5)        # Conv2D: (32, 12, 12) -> (128, 8, 8)
        self.pool2 = nn.MaxPool2d(kernel_size = 2)              # MaxPooling2D: (128, 8, 8) -> (128, 4, 4)
        self.dropout2 = nn.Dropout(p = 0.2)

        # self.flatten = nn.Flatten()                           # Flatten: (128, 4, 4) -> (2048)
        self.fc1 = nn.Linear(128 * 4 * 4, 512)                  # Dense: (2048) -> (512)
        self.dropout3 = nn.Dropout(p = 0.2)
        self.fc2 = nn.Linear(512, 512)                          # Dense: (512) -> (512)
        self.dropout4 = nn.Dropout(p = 0.2)
        self.fc3 = nn.Linear(512, 512)                          # Dense: (512) -> (512)
        self.dropout5 = nn.Dropout(p = 0.2)

        self.fc4 = nn.Linear(512, 10)                           # Dense: (512) -> (10)
        # self.optimizer = optim.SGD(self.parameters(), lr = args.lr)
        # self.loss_function = nn.CrossEntropyLoss()


    def forward(self, x):       
        x = self.pool1(self.dropout1(F.relu(self.conv1(x))))
        x = self.pool2(self.dropout2(F.relu(self.conv2(x))))
        x = x.view(-1, 128 * 4 * 4)
        x = self.dropout3(F.relu(self.fc1(x)))
        x = self.dropout4(F.relu(self.fc2(x)))
        x = self.dropout5(F.relu(self.fc3(x)))
        x = self.fc4(x)

        x = F.softmax(x,dim=1)

        return x

class CNNMnist(nn.Module):
    def __init__(self, args):
        super(CNNMnist, self).__init__()
        self.conv1 = nn.Conv2d(args.num_channels, 10, kernel_size = 5)
        self.conv2 = nn.Conv2d(10, 20, kernel_size = 5)
        self.conv2_drop = nn.Dropout2d(0.2)
        self.fc1 = nn.Linear(320, 50)
        self.fc2 = nn.Linear(50, args.num_classes)

    def forward(self, x):
        x = F.relu(F.max_pool2d(self.conv1(x), 2))
        x = F.relu(F.max_pool2d(self.conv2_drop(self.conv2(x)), 2))
        x = x.view(-1, x.shape[1]*x.shape[2]*x.shape[3])
        x = F.relu(self.fc1(x))
        x = F.dropout(x, training=self.training)
        x = self.fc2(x)

        # x = F.softmax(x,dim=1)
        return x

class CNNCifar(nn.Module):
    def __init__(self, args):
        super(CNNCifar, self).__init__()
        self.conv1 = nn.Conv2d(3, 6, 5)
        self.pool = nn.MaxPool2d(2, 2)
        self.conv2 = nn.Conv2d(6, 16, 5)
        self.fc1 = nn.Linear(16 * 5 * 5, 120)
        self.fc2 = nn.Linear(120, 84)
        self.fc3 = nn.Linear(84, args.num_classes)

    def forward(self, x):
        x = self.pool(F.relu(self.conv1(x)))
        x = self.pool(F.relu(self.conv2(x)))
        x = x.view(-1, 16 * 5 * 5)
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = self.fc3(x)
        return x